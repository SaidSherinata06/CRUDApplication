<?php 
    // fetching data
    $query = "SELECT * FROM tblsubjects";
    $result = mysqli_query($dbc,$query);

?>